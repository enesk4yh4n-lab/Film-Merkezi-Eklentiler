'use strict';
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto'),vm=require('node:vm'),assert=require('node:assert/strict'),acorn=require('acorn'),{execFileSync}=require('node:child_process');
const {expandOrigins}=require('./cdn-origins.cjs');
const args=process.argv.slice(2),action=args.shift(),flags={};for(let i=0;i<args.length;i+=2){assert(args[i].startsWith('--')&&args[i+1],'Use --option value');flags[args[i].slice(2)]=args[i+1];}
const hash=b=>crypto.createHash('sha256').update(b).digest('hex'),write=(n,b)=>{fs.mkdirSync(path.dirname(n),{recursive:true});fs.writeFileSync(n,b);},read=n=>fs.readFileSync(n,'utf8'),canonical=s=>s.replace(/^\uFEFF/,'').replace(/\r\n?/g,'\n');
function discoveryReadme(out,publisher){
 const repoRoot=flags['github-root']?fs.realpathSync(flags['github-root']):out,relative=path.relative(repoRoot,path.join(out,'filmmerkezi-repository.json'));
 assert(!relative.startsWith('..'+path.sep)&&!path.isAbsolute(relative),'--out must be inside --github-root');
 const file=path.join(repoRoot,'README.md'),location=flags['discovery-path']||relative.split(path.sep).join('/');
 assert(/^(?:[A-Za-z0-9_-]+\/)*filmmerkezi-repository\.json$/.test(location),'Invalid --discovery-path');
 const previous=fs.existsSync(file)?read(file):'# '+publisher+'\n',section='<!-- film-merkezi-discovery:start -->\n## Film Merkezi repository\n\nRepository index: `'+location+'`. Find this repository in Film Merkezi using its name or GitHub username, or add its HTTPS address.\n\n<!-- film-merkezi-repository: '+location+' -->\n<!-- film-merkezi-discovery:end -->\n';
 write(file,previous.replace(/\n?<!-- film-merkezi-discovery:start -->[\s\S]*?<!-- film-merkezi-discovery:end -->\n?/g,'').trimEnd()+'\n\n'+section);
}
function schema(){const w={window:null,URL,Uint8Array,Promise,atob,crypto:crypto.webcrypto};w.window=w;for(const n of [path.join(__dirname,'runtime/verify.js'),path.join(__dirname,'runtime/schema.js')])vm.runInNewContext(read(n),w);return w;}
function automaticKey(project,out,publisher){
 const home=path.resolve(process.env.FILM_MERKEZI_SDK_HOME||path.join(os.homedir(),'.film-merkezi-sdk')),inside=(base,child)=>{const rel=path.relative(base,child);return !rel||(!rel.startsWith('..'+path.sep)&&rel!=='..'&&!path.isAbsolute(rel));};
 fs.mkdirSync(home,{recursive:true,mode:0o700});const real=fs.realpathSync(home);assert(!inside(project,real)&&!inside(out,real),'SDK identity directory must be outside the project and repository');
 const file=path.join(real,'publisher-'+hash(publisher.trim().toLowerCase()).slice(0,32)+'.pem');
 if(!fs.existsSync(file)){
  assert(!fs.existsSync(path.join(out,'filmmerkezi-repository.json')),'Existing repository key was not found. Supply its original key with --key; it will not be replaced.');
  if(process.platform==='win32')execFileSync('icacls',[real,'/inheritance:r','/grant:r',(process.env.USERDOMAIN?process.env.USERDOMAIN+'\\':'')+process.env.USERNAME+':(OI)(CI)(F)'],{stdio:'ignore'});
  const pair=crypto.generateKeyPairSync('rsa',{modulusLength:2048});fs.writeFileSync(file,pair.privateKey.export({type:'pkcs8',format:'pem'}),{mode:0o600,flag:'wx'});
 }
 return file;
}
function run(){
 if(action==='keygen'){
  assert(flags.out,'keygen --out <private-key-file>');const file=path.resolve(flags.out);assert(!fs.existsSync(file),'Key already exists; never overwrite it');fs.mkdirSync(path.dirname(file),{recursive:true,mode:0o700});const pair=crypto.generateKeyPairSync('rsa',{modulusLength:2048});fs.writeFileSync(file,pair.privateKey.export({type:'pkcs8',format:'pem'}),{mode:0o600,flag:'wx'});if(process.platform==='win32')execFileSync('icacls',[file,'/inheritance:r','/grant:r',(process.env.USERDOMAIN?process.env.USERDOMAIN+'\\':'')+process.env.USERNAME+':(F)'],{stdio:'ignore'});console.log(JSON.stringify({created:true,privateKeyFile:file,publicKey:pair.publicKey.export({type:'spki',format:'der'}).toString('base64'),fingerprint:hash(pair.publicKey.export({type:'spki',format:'der'}))}));return;
 }
 if(action==='init'){
  assert(flags.project&&flags.id&&flags.name,'init --project <dir> --id <id> --name <name>');const dir=path.resolve(flags.project),w=schema(),siteId=flags['site-id']||flags.id;assert(w.FilmPluginSchema.id(flags.id)&&w.FilmPluginSchema.id(siteId));assert(!fs.existsSync(path.join(dir,'addon.json')),'Project already exists');
  const meta={id:flags.id,name:flags.name,description:'A working ES5 community plugin example. Replace demo data and parser with your site.',type:flags.type||'site',dependencies:[],version:'1.0.0',minAppVersion:'2.0.1',minCoreVersion:'2.1.8',site:{id:siteId,prefix:siteId+':',name:flags.name,base:'https://test-streams.mux.dev'},modules:['site.js'],files:['site.js','catalog.json','streams.json','LICENSE.txt'],origins:['https://test-streams.mux.dev']};if(meta.type==='resolver'){delete meta.site;meta.modules=['resolver.js'];meta.files=['resolver.js','streams.json','LICENSE.txt'];}if(meta.type==='site')meta.dependencies=[{publisher:'PUBLISHER_FINGERPRINT',id:flags['resolver-id']||'r101',minVersion:'1.0.0',maxVersion:'2.0.0'}];assert(['site','resolver'].includes(meta.type));write(path.join(dir,'addon.json'),JSON.stringify(meta,null,2)+'\n');write(path.join(dir,meta.type==='resolver'?'resolver.js':'site.js'),canonical(read(path.join(__dirname,meta.type==='resolver'?'template/resolver.js':'template/site.js'))).replace(/'r101'/g,JSON.stringify(flags['resolver-id']||'r101')));write(path.join(dir,'LICENSE.txt'),read(path.join(__dirname,'LICENSE')));write(path.join(dir,'catalog.json'),JSON.stringify({cards:[{id:'sample',title:flags.name+' test stream',synopsis:'Public test stream for the community plugin example.'}]},null,2)+'\n');write(path.join(dir,'streams.json'),JSON.stringify({url:'https://test-streams.mux.dev/x36xhzz/url_6/193039199_mp4_h264_aac_hq_7.m3u8'},null,2)+'\n');console.log(JSON.stringify({created:true,project:dir,pluginId:flags.id}));return;
 }
 if(action==='pack'){
  assert(flags.project&&flags.out&&flags.publisher,'pack --project <dir> --out <repository-dir> --publisher <name> [--key <private-key-file>]');const project=fs.realpathSync(flags.project);fs.mkdirSync(path.resolve(flags.out),{recursive:true});const out=fs.realpathSync(flags.out),keyPath=fs.realpathSync(flags.key||automaticKey(project,out,flags.publisher));assert(!keyPath.startsWith(project+path.sep)&&!keyPath.startsWith(out+path.sep),'Keep the private key outside both project and published repository');const meta=JSON.parse(read(path.join(project,'addon.json'))),privateKey=crypto.createPrivateKey(read(keyPath)),publicDer=crypto.createPublicKey(privateKey).export({type:'spki',format:'der'}),publicKey=publicDer.toString('base64'),sign=b=>crypto.sign('sha256',Buffer.from(b),privateKey).toString('base64')+'\n',w=schema(),files=new Map();assert(crypto.createPublicKey(privateKey).asymmetricKeyDetails.modulusLength===2048);
  for(const n of meta.files){assert(w.FilmPluginSchema.file(n));const absolute=fs.realpathSync(path.resolve(project,n));assert(absolute.startsWith(project+path.sep),'Project paths cannot escape through symlinks');const text=canonical(read(absolute));assert(!/-----BEGIN [^-]*PRIVATE KEY-----/.test(text),'A private key must never be published');if(n.endsWith('.js'))acorn.parse(text,{ecmaVersion:5});files.set(n,Buffer.from(text));}
  const policy='FILM-MERKEZI-ORIGINS-1\n'+expandOrigins(meta,project).join('\n')+'\n';w.FilmUpdateVerify.networkPolicy(policy);if(policy.includes('{n}'))assert(w.FilmPluginSchema.compare(meta.minAppVersion,'1.4.1')>=0,'Numeric origin permissions require minAppVersion 1.4.1 or later');files.set('network-policy.txt',Buffer.from(policy));files.set('network-policy.signature.txt',Buffer.from(sign(policy)));
  meta.dependencies=(meta.dependencies||[]).map(d=>({...d,publisher:d.publisher==='PUBLISHER_FINGERPRINT'?hash(publicDer):d.publisher}));
  const minimum=w.FilmPluginSchema.compare(meta.minAppVersion,'2.0.1')<0?'2.0.1':meta.minAppVersion;
  const m={schemaVersion:2,apiVersion:2,type:meta.type,dependencies:meta.dependencies||[],minCoreVersion:meta.minCoreVersion,id:meta.id,name:meta.name,version:meta.version,minAppVersion:minimum,requires:meta.requires,site:meta.site,modules:meta.modules,networkPolicy:{file:'network-policy.txt',signature:'network-policy.signature.txt'},files:[...files].map(([n,b])=>({path:n,size:b.length,sha256:hash(b)}))},text=JSON.stringify(m,null,2)+'\n';w.FilmPluginSchema.manifest(text,minimum);const relative='packages/'+m.id+'/'+m.version+'/manifest.json',manifestPath=path.join(out,relative);if(fs.existsSync(manifestPath))assert.equal(read(manifestPath),text,'Published plugin versions are immutable; bump addon.json version');

  let repo={schemaVersion:2,id:flags['repository-id']||'community',name:flags.publisher,publicKey,revision:0,plugins:[]};if(fs.existsSync(path.join(out,'filmmerkezi-repository.json'))){repo=JSON.parse(read(path.join(out,'filmmerkezi-repository.json')));assert.equal(repo.schemaVersion,2,'Use a new v2 repository output; old packages are not migrated implicitly');assert.equal(repo.publicKey,publicKey,'This repository belongs to another publisher key');assert(crypto.verify('sha256',Buffer.from(read(path.join(out,'filmmerkezi-repository.json'))),crypto.createPublicKey(privateKey),Buffer.from(read(path.join(out,'filmmerkezi-repository.sig')),'base64')));}
  for(const[n,b]of files)write(path.join(path.dirname(manifestPath),'runtime',n),b);write(manifestPath,text);write(manifestPath.replace(/\.json$/,'.sig'),sign(text));const entry={id:m.id,type:m.type,name:m.name,version:m.version,description:meta.description||'',manifest:relative,manifestSha256:hash(text),minAppVersion:m.minAppVersion,minCoreVersion:m.minCoreVersion,requires:m.requires};
  const prior=repo.plugins.find(p=>p.id===m.id);
  const historical=(repo.alternatives||[]).filter(p=>p.manifest!==relative);
  if(prior){
   const order=w.FilmPluginSchema.compare(m.version,prior.version);
   assert(order>=0,'Cannot replace the latest package with an older version');
   if(order>0){
    const oldRaw=read(path.join(out,prior.manifest));
    assert.equal(hash(oldRaw),prior.manifestSha256,'Previous manifest hash mismatch');
    assert(crypto.verify('sha256',Buffer.from(oldRaw),crypto.createPublicKey(privateKey),Buffer.from(read(path.join(out,prior.manifest.replace(/\.json$/,'.sig'))),'base64')),'Previous manifest signature mismatch');
    const old=w.FilmPluginSchema.manifest(oldRaw);
    historical.push({...prior,minAppVersion:old.minAppVersion,minCoreVersion:old.minCoreVersion,requires:old.requires});
   }
  }
  repo.plugins=repo.plugins.filter(p=>p.id!==m.id).concat(entry);repo.alternatives=historical;repo.revision++;const index=JSON.stringify(repo,null,2)+'\n';w.FilmPluginSchema.repository(index);write(path.join(out,'filmmerkezi-repository.json'),index);write(path.join(out,'filmmerkezi-repository.sig'),sign(index));discoveryReadme(out,flags.publisher);console.log(JSON.stringify({packed:true,repository:out,plugin:m.id,version:m.version,files:files.size,fingerprint:hash(publicDer),coreSigningKeyRequired:false}));return;
 }
 throw Error('Commands: keygen, init, pack. See SDK/README.md');
}
try{run();}catch(e){console.error(e.message);process.exitCode=1;}
