﻿# Film Merkezi SDK 2.0.1

Tizen 3 / Chromium 47 için bağımsız **site** ve **çözümleyici** paketleri üretir. WGT 2.0.1 / çekirdek 2.1.8 gerekir. Eski paket API'si desteklenmez.

## Başlangıç

Geliştirme bilgisayarında Node.js 20+ kullanın; SDK klasöründe `npm install` çalıştırın. TV'nin bilgisayara veya ek çalışma sunucusuna ihtiyacı yoktur.

```text
node SDK/cli.cjs init --project examples/r101 --id r101 --name R101 --type resolver
node SDK/cli.cjs init --project examples/p101 --id p101 --name P101 --type site --resolver-id r101
node SDK/cli.cjs pack --project examples/r101 --out my-repository --publisher "Independent publisher" --repository-id independent
node SDK/cli.cjs pack --project examples/p101 --out my-repository --publisher "Independent publisher" --repository-id independent
```

Örnek site kamuya açık test akışını sağlayan R101'e bağlıdır. `addon.json`, katalog verileri ve kodu kendi sitenize göre değiştirin. `PUBLISHER_FINGERPRINT` bağımlılık değeri paketlemede sizin yayıncı parmak izinize çevrilir. Başka yayıncıya bağımlılık için onun açık anahtar parmak izini yazın. Film Merkezi geliştiricisinin onayı veya özel anahtarı gerekmez.

RSA-2048 anahtarı ilk üretimde proje/depo dışında kullanıcı hesabının `.film-merkezi-sdk/` klasöründe oluşturulur; sonraki üretimlerde korunur. Kaybetmeyin, paylaşmayın. `keygen` ve `--key` komutları kullanılabilir. Mevcut deponun anahtarı yoksa yeni anahtarla üzerine yazılmaz.

## Paketler ve arayüzler

Manifest ve depo biçimi v2'dir. Site `home/list/search/detail`, `cards/next` ve gerçek bölüm verilerini sunar. Çözümleyici `resolve/cancel` sunar. Bağımlılık yayıncı parmak izi, kimlik, minimum dahil/maksimum hariç sürümle belirtilir. Çözümleyicinin tek etkin sürümü bulunur; uyumsuz bağımlılık kurulumu durdurur.

`FilmPlugins.context()` modül yüklenirken alınır. Paket `context.createClient()` ile kendi istemcisini oluşturur. Site `context.createResolver('r101')` ile bildirilen bağımlılığı çağırır. Çözümleyici `context.registerResolver({create: function(context, log, now) { return {resolve: ..., cancel: ...}; }})` ile kaydolur. Medya kaynağının paket sahipliği korunur.

Özel HLS yükleyicisi gerekiyorsa `template/media-loader.js` örneğini resolver paketinin dosya/modül listesine ekleyin. `registerLoader` oturuma bağlı yükleyici kaydeder; kaynak `loaderId`, `loaderConfig` ve `playbackRequirements.customLoader` taşır. Global player/ağ işlevleri değiştirilmemelidir. Yeni codec, DRM veya native cihaz yetkisi eklenmez.

## Afiş boyutları

Çekirdek 2.1.4 ve sonrasında karttaki `poster` liste afişidir. İsteğe bağlı `posterLarge`, detay ve vitrinde kullanılır; bulunmazsa `poster` kullanılır. İki alanı da doğrudan indirilebilir, izinli HTTPS görsel adresi olarak sağlayın. Sitenin gerçekten sunduğu küçük görseli seçin; TV'de büyük resmi indirip küçültmek gereksiz indirme ve decode belleğini azaltmaz. P002 örneği liste için 360×540, büyük görünüm için 720×1080 sınırlarına oranı korunarak sığan CDN resimlerini kullanır. Bu alanı isteyen paket minimum çekirdek sürümünü 2.1.4 bildirmelidir. SDK araç sürümü değişmez.

## İsteğe bağlı hazır katalog filtreleri

Çekirdek 2.1.5 ile site tanımı `supportsQuickFilters: true` bildirebilir. `options()` çıktısındaki `quickFilters` en fazla 32 kayıt içerir. Her kayıt `{id, label, types, query}` biçimindedir: örneğin `{id:'genre:action', label:'Aksiyon', types:['movie','series'], query:{filters:{genre:'action'}}}`. `query` sitenin gerçekten desteklediği `list(query, next, force)` sorgusudur; sunulmayan filtreyi bildirmeyin. Ortak listede yalnız o filtreyi destekleyen siteler sorgulanır. Destek bildirmeyen eski paketler için ek `options()` isteği yapılmaz.

Ortak kimlikler: `new`, `most-viewed`, `genre:action`, `genre:science-fiction`, `genre:comedy`, `genre:romance`. Diğer kimliklerde paket etiketi gösterilir. Bu kabiliyeti kullanan paketin minimum çekirdek sürümü 2.1.5 olmalıdır. Bu çalışma mevcut site paketlerini güncellemez.

GitHub keşfi için README'de `film-merkezi` ve `filmmerkezi-repository.json` bulunmalıdır. Keşif yayıncıya özel değildir; sonuç güven onayı veya otomatik kurulum sayılmaz. İşaret kullanmayan depo HTTPS adresiyle eklenebilir.

## Yayın ve güven

### Özel katalog bölümleri (çekirdek 2.1.8)

Site kaydı isteğe bağlı `catalogSections: ['animation', 'drama-short']` kabiliyetini bildirebilir. Yalnız gerçekten sunduğu bölümleri yazmalıdır. Çekirdek bu bölümlerde `list({section: 'animation'}, next)` veya `list({section: 'drama-short'}, next)` çağırır; mevcut `cards/next`, iptal ve sayfalama sözleşmesi değişmez. Animasyon bölümü film ve dizi döndürebilir.

Kart/detail üzerinde doğrulanmış `catalogSection`, `genres`, `identityCategories`, `catalogCategories` veya dizi için `productionCountries` kullanılabilir. Bölüm seçimi `type`, içerik kimliği ve bölüm sırasını değiştirmez. `drama-short` Kore/Asya ve kısa bölümlü dizilerdir; genel Dram türü değildir. Kategorisi öğrenilen kayıt normal Film/Dizi görünümünden ayrılır. Başlıktan veya kısa toplam süreden kategori tahmini yapılmaz. Ayrı liste sunmayan bir sitede önceden öğrenilmiş kayıtlar ek ağ isteği olmadan gösterilebilir.

Paketleme `filmmerkezi-repository.json`, `.sig`, imzalı manifestler ve dosya özetlerini üretir. README'ye keşif işareti eklenir; alt klasöre yayın için `--github-root <depo-kökü>` kullanın. Komut GitHub'a yükleme yapmaz.

Kullanıcı **Güncelleme Merkezi → Eklenti depoları** üzerinden HTTPS adresini ekler veya GitHub'da arar. Hazır/resmî depo yoktur. Site seçildiğinde çözümleyiciler kurulum özetinde gösterilir. Kullanıcı eklemedikçe başka depo aranmaz/eklenmez.

Yalnız gereken HTTPS kökenlerini `origins` alanında bildirin. TLS, imza ve ağ izinleri korunur. Paket 4 MiB, dosya 1 MiB, toplam eklenti alanı 8 MiB ve toplam 128 köken sınırı vardır. Runtime ES5 olmalıdır. Yayımlanan sürümler değişmezdir; değişiklik için sürüm artırın.

Video CDN izinleri, tek çözümleyicinin kullandığı gruplar dahil, ortak bir JSON dosyasında tutulabilir. Çözümleyicinin `addon.json` dosyasında `cdnRegistry` bu dosyanın göreli yolunu, `origins` içindeki `@cdn/rapidrame` gibi bir değer de gereken grubu belirtir. Grup, HTTPS kökenlerinden oluşan bir dizidir. SDK paketleme sırasında yalnız seçilen grupları diğer izinlerle birleştirip paketin `network-policy.txt` dosyasını imzalar. Site ve katalog kökenleri normal `origins` girdileri olarak kalır. Bir grubun izinleri değişirse onu kullanan yayımlanmış paketler yeni sürüm numarasıyla üretilir.

Eklentiler JavaScript sandbox'ı değildir; uygulama yetkileriyle çalışırlar. İmza içerik lisansı veya zararsızlık garantisi değildir. Platform metin taşımalarında yönlendirme görünürlüğü native TLS yolundan daha sınırlıdır. Ayrıntılı sözleşme kaynak dağıtımındaki `docs/MODULER_EKLENTI_2.0.0.md` belgesindedir.

Grafik geliştirme aracı planlanmaktadır, henüz yayımlanmamıştır. `npm test` bağımsız yayıncı, anahtarın korunması, paketleme ve bozuk imza kontrollerini çalıştırır.
